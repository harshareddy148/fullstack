INSERT INTO customer (id, name, birth_date, email) VALUES (10001, 'houari', sysdate(), 'admin@houarizegai.net');
INSERT INTO customer (id, name, birth_date, email) VALUES (10002, 'omar', sysdate(), 'omar@houarizegai.net');
INSERT INTO customer (id, name, birth_date, email) VALUES (10003, 'ali', sysdate(), 'ali@houarizegai.net');